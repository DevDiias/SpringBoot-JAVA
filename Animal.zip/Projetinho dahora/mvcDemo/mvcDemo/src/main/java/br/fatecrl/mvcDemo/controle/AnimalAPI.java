package br.fatecrl.mvcDemo.controle;
import br.fatecrl.mvcDemo.models.Animal;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/animal")

public class AnimalAPI {

    public List<br.fatecrl.mvcDemo.models.Animal> animal = new ArrayList<Animal>();

    public AnimalAPI() {
        animal.add(new Animal("mamifero", "Vaquinha"));
        animal.add(new Animal("Ovíparo", "Cobra"));
        animal.add(new Animal("Ave", "águia"));
    }
    @GetMapping
    public List<Animal> getAnimal(){
        return animal;
    }
}

