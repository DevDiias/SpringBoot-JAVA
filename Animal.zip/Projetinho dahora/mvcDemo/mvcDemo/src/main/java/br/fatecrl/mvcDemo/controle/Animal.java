package br.fatecrl.mvcDemo.controle;

public class Animal {
}
