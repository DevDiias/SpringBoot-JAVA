package br.fatecrl.mvcDemo.controle;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import br.fatecrl.mvcDemo.models.Animal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/animais")
public class AnimalController {


    public List<Animal> animal = new ArrayList<Animal>();

    public AnimalController() {
        animal.add(new Animal("Mamifero", "Vaquinha"));
        animal.add(new Animal("Ovípero", "Cobrinha"));
        animal.add(new Animal("Ave", "Águia"));


    }
    @GetMapping
    public String getAnimal(Model model){

        model.addAttribute("animal", animal);
        return "animal";

    }
}



